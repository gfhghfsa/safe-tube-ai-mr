# YouTube Filter Backend

Backend بسيط باش يجلب فيديوهات من YouTube ويعمل فلترة لمحتوى NSFW.

## نشر على Render بدون تجربة محلية
1. رفع المشروع كامل لـGitHub.
2. Render → New → Web Service → Connect repo.
3. Fill:
   - Environment: Node
   - Branch: main
   - Build Command: `npm install`
   - Start Command: `npm start`
4. تحت Environment Variables → أضف مفتاحك:
